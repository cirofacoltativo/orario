import { Service } from '../types';

export const TIME_SLOTS = ['8-14', '14-20', '20-8'] as const;

export const SERVICE_ORDER = [
  'Reparto 8-14',
  'Sala Parto 8-14',
  'Reparto 14-20',
  'Sala Parto 14-20',
  'Guardia Notturna',
  'Primo Reperibile',
  'Secondo Reperibile',
  'Terzo di Reparto',
  'Sala Operatoria',
  'Ambulatorio Gravidanza a Rischio',
  'Ambulatorio Gravidanza a Termine',
  'Colposcopia',
  'Ambulatorio Integrato',
  'Ambulatorio Chirurgico',
  'Isteroscopie',
  'Eco Ostetriche',
  'Ecografie II Livello',
  'Ambulatorio I Trimestre',
  'GOM',
  'Valtiberina'
];

export const DEFAULT_SERVICES: Omit<Service, 'id'>[] = [
  { name: 'Reparto 8-14', duration: 360, timeSlot: '8-14', days: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'], doctorsRequired: 1 },
  { name: 'Sala Parto 8-14', duration: 360, timeSlot: '8-14', days: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'], doctorsRequired: 1 },
  { name: 'Reparto 14-20', duration: 360, timeSlot: '14-20', days: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'], doctorsRequired: 1 },
  { name: 'Sala Parto 14-20', duration: 360, timeSlot: '14-20', days: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'], doctorsRequired: 1 },
  { name: 'Guardia Notturna', duration: 720, timeSlot: '20-8', days: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'], doctorsRequired: 1 },
  { name: 'Primo Reperibile', duration: 720, timeSlot: '20-8', days: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'], doctorsRequired: 1 },
  { name: 'Secondo Reperibile', duration: 720, timeSlot: '20-8', days: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'], doctorsRequired: 1 },
  { name: 'Terzo di Reparto', duration: 360, timeSlot: '8-14', days: ['Monday', 'Wednesday', 'Friday'], doctorsRequired: 1 },
  { name: 'Sala Operatoria', duration: 360, timeSlot: '8-14', days: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'], doctorsRequired: 2 },
  { name: 'Ambulatorio Gravidanza a Rischio', duration: 360, timeSlot: '8-14', days: ['Monday', 'Wednesday', 'Friday'], doctorsRequired: 1 },
  { name: 'Ambulatorio Gravidanza a Termine', duration: 360, timeSlot: '8-14', days: ['Tuesday', 'Thursday'], doctorsRequired: 1 },
  { name: 'Colposcopia', duration: 360, timeSlot: '8-14', days: ['Tuesday', 'Thursday'], doctorsRequired: 1 },
  { name: 'Ambulatorio Integrato', duration: 360, timeSlot: '8-14', days: ['Monday', 'Wednesday'], doctorsRequired: 1 },
  { name: 'Ambulatorio Chirurgico', duration: 360, timeSlot: '8-14', days: ['Friday'], doctorsRequired: 1 },
  { name: 'Isteroscopie', duration: 360, timeSlot: '8-14', days: ['Tuesday', 'Thursday'], doctorsRequired: 1 },
  { name: 'Eco Ostetriche', duration: 360, timeSlot: '8-14', days: ['Monday', 'Friday'], doctorsRequired: 1 },
  { name: 'Ecografie II Livello', duration: 360, timeSlot: '8-14', days: ['Tuesday', 'Thursday'], doctorsRequired: 1 },
  { name: 'Ambulatorio I Trimestre', duration: 360, timeSlot: '8-14', days: ['Wednesday'], doctorsRequired: 1 },
  { name: 'GOM', duration: 360, timeSlot: '8-14', days: ['Wednesday'], doctorsRequired: 1 },
  { name: 'Valtiberina', duration: 360, timeSlot: '8-14', days: ['Wednesday'], doctorsRequired: 1 },
];

export const SCHEDULING_RULES = {
  REST_AFTER_NIGHT_SHIFT: true,
  FIRST_REPERIBILE_NO_MORNING_AFTER: true,
  DISTRIBUTE_NIGHT_SHIFTS: true,
  EVENING_SHIFT_BEFORE_NIGHT_SHIFT_ALLOWED: false,
};